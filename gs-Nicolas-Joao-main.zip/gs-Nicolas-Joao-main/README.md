# global-solution-dbe-1-semestre

Entrega global solution DBE prof joão.
Dupla 
Rafael Vinícius RM 86981
João Pedro Marques Nardi RM85846.
